<?php

namespace HXPHP\System\Configs\Environments;

use HXPHP\System\Configs as Configs;

class EnvironmentProduction extends Configs\AbstractEnvironment
{
	
}