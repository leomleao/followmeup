<?php 

class Default extends \HXPHP\System\Model
{
	
}